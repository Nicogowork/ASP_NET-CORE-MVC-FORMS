using System.ComponentModel.DataAnnotations;

namespace ASP_NET_Core_Forms.Models
{
    public class Cliente
    {
        [Required(ErrorMessage = "Nome obrigatório", AllowEmptyStrings = false)]
        [Display(Name = "Nome do Utilizador")]
        public string Nome { get; set; } = string.Empty;

        [Display(Name = "Apelido")]
        public string Apelido { get; set; } = string.Empty;

        [StringLength(10, MinimumLength = 4, ErrorMessage = "A password deve ter entre 4 e 10 caracteres")]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email obrigatório", AllowEmptyStrings = false)]
        [StringLength(100, ErrorMessage = "Permitido máximo de 100 caracteres")]
        [DataType(DataType.EmailAddress, ErrorMessage = "Email inválido!")]
        [EmailAddress(ErrorMessage = "Email inválido!")]
        [Display(Name = "Email")]
        public string Email { get; set; } = string.Empty;
    }
}
