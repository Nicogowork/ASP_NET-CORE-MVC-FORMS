using Microsoft.AspNetCore.Mvc;
using ASP_NET_Core_Forms.Models;

namespace ASP_NET_Core_Forms.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home/Index
        public IActionResult Index()
        {
            return View();
        }

        // ========== FORM 1 - Parâmetros como variáveis ==========
        
        // GET: Home/Form_1
        public IActionResult Form_1()
        {
            return View();
        }

        // POST: Home/Form_1
        [HttpPost]
        public ActionResult Form_1(string utilizador, string password, string? lembrar)
        {
            Cliente cliente = new Cliente 
            { 
                Nome = utilizador, 
                Password = password 
            };
            
            ViewBag.Lembrar = lembrar != null ? "Sim" : "Não";   

            return View("Dados_recebidos", cliente);
        }

        // ========== FORM 2 - FormCollection ==========
        
        // GET: Home/Form_2
        public IActionResult Form_2()
        {
            return View();
        }

        // POST: Home/Form_2
        [HttpPost]
        public ActionResult Form_2(IFormCollection formCollection)
        {
            string nome = formCollection["Nome"]!;
            string apelido = formCollection["Apelido"]!;
            string email = formCollection["Email"]!;

            Cliente cliente = new Cliente 
            { 
                Nome = nome, 
                Apelido = apelido, 
                Email = email 
            };

            return View("Dados_recebidos", cliente);
        }

        // ========== FORM 3 - Model Binding ==========
        
        // GET: Home/Form_3
        public IActionResult Form_3()
        {
            return View();
        }

        // POST: Home/Form_3
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Form_3(Cliente cliente)
        {
            if (ModelState.IsValid)
            {
                return View("Dados_recebidos", cliente);
            }
            
            return View(cliente);
        }

        // ========== Dados Recebidos ==========
        
        public IActionResult Sobre()
        {
            return View();
        }

        public IActionResult Conteudo()
        {
            return View();
        }
    }
}
