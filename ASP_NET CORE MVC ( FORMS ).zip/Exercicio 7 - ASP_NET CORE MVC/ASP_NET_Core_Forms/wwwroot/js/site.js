// JavaScript personalizado para o projeto ASP.NET Core Forms

// Exemplo: Confirmação antes de submeter formulários
document.addEventListener('DOMContentLoaded', function() {
    // Adicionar animações ou validações customizadas aqui, se necessário
    console.log('ASP.NET Core Forms - Aplicação carregada com sucesso!');
});

// Função para mostrar mensagens de confirmação (exemplo)
function confirmarEnvio(mensagem) {
    return confirm(mensagem || 'Deseja realmente enviar os dados?');
}
